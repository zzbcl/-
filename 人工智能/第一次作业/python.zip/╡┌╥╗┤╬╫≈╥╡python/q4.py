import numpy as np
import matplotlib.pyplot as plt

# 数据
x = np.array([0, 0.8, 1.6, 3, 4.0, 5.0]).reshape(-1, 1)
y = np.array([0.5, 1, 4, 5, 6, 8])

# 添加偏置项
X_b = np.hstack((np.ones((x.shape[0], 1)), x))

# LLS
rate = 0.02  # 这个rate在LLS中未使用，但保留以与LMS对比
epochs = 200  # 这个epochs在LLS中未使用，但保留以与LMS对比
omega1 = np.linalg.inv(X_b.T @ X_b) @ X_b.T @ y

# 绘制 LLS 结果
t = np.linspace(-1, 7, 300).reshape(-1, 1)
ft1 = omega1[0] + omega1[1] * t
plt.figure()
plt.plot(t, ft1, 'b', linewidth=2)
plt.plot(x, y, 'ro', markersize=10)
plt.legend(['LLS results', 'Data points'])
plt.title('LLS method')
plt.show()

# LMS
omega2 = np.random.rand(2)
bias_history = []
weight_history = []

for i in range(epochs):
    predictions = omega2 @ X_b.T
    error = y - predictions
    omega2 += rate * error @ X_b  # 注意：这里X_b.T是因为我们需要将误差与输入特征（包括偏置项）相乘来更新权重
    bias_history.append(omega2[0])
    weight_history.append(omega2[1])

# 绘制 LMS 结果
ft2 = omega2[0] + omega2[1] * t
plt.figure()
plt.plot(t, ft2, 'g', linewidth=2)
plt.plot(x, y, 'ro', markersize=10)
plt.legend(['LMS results', 'Data points'])
plt.title('LMS method')
plt.show()

print(omega1)
print(omega2)
# 绘制 LMS 权重轨迹
plt.figure()
plt.plot(range(1, epochs + 1), bias_history, 'b', linewidth=2)
plt.plot(range(1, epochs + 1), weight_history, 'r', linewidth=2)
plt.title('LMS weight trajectory (learning rate=0.02)')
plt.legend(['Bias (b)', 'Weight (w)'])
plt.show()