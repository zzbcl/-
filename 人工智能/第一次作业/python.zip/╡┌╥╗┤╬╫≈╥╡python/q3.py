import numpy as np
import matplotlib.pyplot as plt


# 定义训练函数
def training(x, y, rates, epochs, name):
    dim = x.shape[0]
    num = x.shape[1]
    omegas = np.random.rand(epochs + 1, dim + 1)

    for k, r in enumerate(rates):
        for t in range(epochs):
            pos = (t % num) + 1
            now = np.concatenate(([1], x[:, pos - 1]))
            d = np.sum(now * omegas[t, :])
            d = d > 0
            e = d - y[pos - 1]
            omegas[t + 1, :] = omegas[t, :] - e * r * now

        plt.figure()
        plt.subplot(len(rates), 1, k + 1)
        t = np.arange(0, epochs + 1)
        if dim == 1:
            plt.plot(t, omegas[:, 0], label='b')
            plt.plot(t, omegas[:, 1], label='w1')
        elif dim == 2:
            plt.plot(t, omegas[:, 0], label='b')
            plt.plot(t, omegas[:, 1], label='w1')
            plt.plot(t, omegas[:, 2], label='w2')
        plt.legend()
        plt.title(f'{name} (learning rate={r})')

    return omegas[-1, :]


# 定义绘制决策边界的函数
# 定义绘制决策边界的函数
def drawDecBou(x, y, omega, name):
    dim = x.shape[0]
    num = x.shape[1]

    plt.figure()
    if dim == 2:
        t = np.linspace(-1, 2, 100)
        for i in range(num):
            if y[i]:
                plt.plot(x[0, i], x[1, i], 'r*', markersize=10)
            else:
                plt.plot(x[0, i], x[1, i], 'go', markersize=10)
        o1, o2, o3 = omega[0], omega[1], omega[2]
        ft = -(t * o2 + o1) / o3
        plt.plot(t, ft, linewidth=2)  # 这里修改了 'LineWidth' 为 'linewidth'

    elif dim == 1:
        t = np.linspace(-1, 2, 100)
        for i in range(num):
            if y[i]:
                plt.plot(x[0][i], 0, 'r*', markersize=10)
            else:
                plt.plot(x[0][i], 0, 'go', markersize=10)
        ft = np.ones(len(t)) * omega[0]
        plt.plot(ft, t, linewidth=2)  # 同样修改了 'LineWidth' 为 'linewidth'

    plt.xlim([-0.5, 1.5])
    plt.ylim([-0.5, 1.5])
    plt.axis('equal')
    plt.title(name)
    plt.show()


# 主程序
rates = [0.01, 0.1, 1, 5]
epochs = 100
x1 = np.array([[0, 0, 1, 1], [0, 1, 0, 1]])

# AND
y1 = np.array([0, 0, 0, 1])
omega1 = training(x1, y1, rates, epochs, 'AND')
drawDecBou(x1, y1, omega1, 'AND')

# OR
y2 = np.array([0, 1, 1, 1])
omega2 = training(x1, y2, rates, epochs, 'OR')
drawDecBou(x1, y2, omega2, 'OR')

# COMPLEMENT
x2 = np.array([[0, 1]])
y3 = np.array([1, 0])
omega3 = training(x2, y3, rates, epochs, 'COMPLEMENT')
drawDecBou(x2, y3, omega3, 'COMPLEMENT')

# EXCLUSIVE OR
y5 = np.array([0, 1, 1, 0])
omega5 = training(x1, y5, rates, epochs, 'XOR')
drawDecBou(x1, y5, omega5, 'XOR')
print(omega1,omega2,omega3,omega5)